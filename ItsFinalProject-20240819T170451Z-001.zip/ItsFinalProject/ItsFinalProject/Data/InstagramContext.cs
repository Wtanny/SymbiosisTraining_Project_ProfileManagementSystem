﻿using ItsFinalProject.Models;
using Microsoft.EntityFrameworkCore;

using System.Collections.Generic;
using System.Reflection.Emit;

namespace ItsFinalProject.Data
{
    public class InstagramContext : DbContext
    {
        public InstagramContext(DbContextOptions<InstagramContext> options) : base(options) { }
        public DbSet<Instagram> Insta { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Instagram>().HasKey(a => a.Ino); // Explicitly define the primary key
            base.OnModelCreating(modelBuilder); // Call the base class implementation
        }
    }
}
